function Solution = Fitness(x,fun)   
    if  strcmp(fun,'Case') 
        Solution = Case(x);
    end
end

function Solution = Case(X)
    Obj = FEA(X);
    Solution.decs = X;
    Solution.objs = Obj(:,[2,1]);
    Solution.cons = Obj(:,3) - 20;
end

function Obj = FEA(x)
PartID_idx = [2000331 2000332 2000406 2000407 2000408 2000409 2000410 2000411 2000412 2000413 2000414 2000415];
x          = [x(:,1), x(:,2), x(:,3), x(:,3), x(:,4), x(:,4), x(:,5), x(:,6), x(:,7), x(:,7), x(:,5), x(:,8)];
path       = 'X:\XXX\Automotive_Rear_Safety_System';
pathls     = 'F:\LSDYNA\program'; % Path of LSDYNA
[m, n]     = size(x);
Obj        = zeros(m,3);
for j = 1 : size(x,1)
    %% Update design variables
    for i = 1 : size(x,2)
        filename     = [path,'\houpeng.k'];
        PartID       = PartID_idx(i);                                                         
        newthickness = x(j,i);                                                              

        strPartID    = num2str(PartID);                                                       
        strnewtemp   = num2str(newthickness);                                                
        LenstrPID    = length(strPartID);
        LenstrTID    = length(strnewtemp);

        for jk = 1 : 10 - LenstrPID
            strPartID = [' ',strPartID];                                                   
        end

        for jl = 1 : 10 - LenstrTID
            strnewtemp = [' ',strnewtemp];                                                  
        end
        LenstrPID = length(strPartID);
        LenstrTID = length(strnewtemp);
        
        if LenstrPID == 10 && LenstrTID == 10
            strnew = [strnewtemp,strnewtemp,strnewtemp,strnewtemp];                        

            [fid,errmsg] = fopen(filename,'r+');
            if fid < 0
                disp(errmsg);
            else
                flag = 1;
                while (~feof(fid))                                                          
                    tline = fgetl(fid);
                    if ischar(tline)
                        tline = upper(tline);                        
                        if ~isempty(strfind(tline, '*SECTION_SHELL'))                     
                            flag_part = (1==0);
                            for k = 1:3                                                      
                                tpart = fgetl(fid);
                            end
                
                            if strcmp(strPartID,tpart(1:10))                              
                                fgetl(fid);                                               
                                fseek(fid,0,'cof');                   
                                fprintf(fid,'%s',strnew);            
                                flag = 0;
                                break;
                            end
                        end
                    end 
                end
            end
            fclose(fid);   
        end
    end   
    
    %% Run LS DYNA
    setenv('OMP_NUM_THREADS','12');
    fid = fopen([path,'\Calculation.bat'],'w');
    fprintf(fid,'%s\n',['cd ',path]);
    fprintf(fid,'%s\n',['path=',pathls]);
    fprintf(fid,'%s\n','ls-dyna_smp_s_R11_0_winx64_ifort131.exe i=houpeng.k');
    fclose(fid);
    system([path,'\Calculation.bat'])
    
    %% Write MV_OPT_OUTPUT.cfile
    fid          = fopen([path,'\MV_OPT_OUTPUT.cfile'],'w');
    
    fprintf(fid,'%s\n',['ascii rcforc open "',path,'\rcforc" 0']);
    fprintf(fid,'%s\n','ascii rcforc plot 4 Sl-2'); 
    fprintf(fid,'%s\n',['xyplot 1 savefile curve_file "',path,'\Force1.txt" 1 all']);
    
    fprintf(fid,'%s\n',['ascii rcforc open "',path,'\rcforc" 0']);
    fprintf(fid,'%s\n','ascii rcforc plot 4 Ma-2');
    fprintf(fid,'%s\n',['xyplot 1 savefile curve_file "',path,'\Force2.txt" 1 all']);
    
    for read_i = 1 : length(PartID_idx)
        fprintf(fid,'%s\n',['ascii matsum open "',path,'\matsum" 0']);
        fprintf(fid,'%s\n',['ascii matsum plot 1 ',num2str(PartID_idx(read_i))]);
        fprintf(fid,'%s\n',['xyplot 1 savefile curve_file "',path,'\Energy',num2str(read_i),'.txt" 1 all']);
    end
    
    fprintf(fid,'%s\n','exit');
    fclose(fid);     

    %% Run LS prepost  
    fid = fopen([path,'\LS_postprocess.bat'],'w');
    fprintf(fid,'%s\n',['cd ',path]);
    fprintf(fid,'%s\n',['path=',pathls]);
    fprintf(fid,'%s\n','lsprepost.exe c=MV_OPT_OUTPUT.cfile');
    fclose(fid);
    system([path,'\LS_postprocess.bat'])

    %% Extract data 
    
    %% Peak Crushing Force (PCF) kN
    fid1   = fopen([path,'\Force1.txt']);
    force1 = textscan(fid1,'%f%f','headerLines',8); 
    fclose(fid1);
    fid2   = fopen([path,'\Force2.txt']);
    force2 = textscan(fid2,'%f%f','headerLines',8); 
    fclose(fid2);
    Obj(j,1) = max(abs(force1{1,2}) + abs(force2{1,2}))/1000;
    
    %% Energy Absorption (EA) kJ 
    energy_part = [];
    for read_i = 1:length(PartID_idx)
        fid3   = fopen([path,'\Energy',num2str(read_i),'.txt']);
        energy = textscan(fid3,'%f%f','headerLines',8); 
        fclose(fid3);
        energy_part(read_i) = max(abs(energy{1,2}));
    end
    Obj(j,2) = -sum(energy_part)/1000000;
    
    %% Total Mass Kg
    name5     = [path,'\d3hsp'];
    fid       = fopen(name5,'r');
    read_flag = (0 == 1);
    num_id    = 1;
    mp        = [];
    while 1
        tline=fgetl(fid);
        if strncmpi(tline,' summary of mass ',17) == 1
            read_flag = (0 == 0);
        end
        line_split = strtrim(tline);
        line_split = strsplit(line_split,' ');
        if length(line_split) < 4
            ss = false;
        else
            s1 = strcmp(line_split{1},'part');
            s2 = strcmp(line_split{2},'id');
            s3 = strcmp(line_split{3},'=');
            s4 = strcmp(line_split{4},num2str(PartID_idx(num_id)));
            ss = s1 & s2 &s3 & s4;
        end
        
        if read_flag && ss
            num_id = num_id + 1;
            for k = 31 : 44
                mp1(k-30) = tline(k);
            end
            mp(num_id) = str2num(mp1);
        end
        
        if strncmpi(tline,' t o t a l  m a s s',19) == 1 || num_id > 12
            break
        end
    end
    fclose(fid);
    Obj(j,3) = sum(mp)*1000;
end
end      