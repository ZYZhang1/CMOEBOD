function Problem = ProblemSet(M,D,N,FE,fun)   
    if strcmp(fun,'Case')
        Problem.M = 2;
        Problem.N = N;
        Problem.D = 8;
        Problem.upper = [2.2*ones(1,7),1.5];
        Problem.lower = [0.8*ones(1,7),0.4];
        Problem.MaxFE = FE;
        Problem.encoding = 'real';
        Problem.Optimum  = [2200,2200];
    end
end
