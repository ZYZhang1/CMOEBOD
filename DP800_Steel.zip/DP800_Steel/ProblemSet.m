function Problem = ProblemSet(M,D,N,FE,fun)   
    if strcmp(fun,'Case')
        Problem.M = 2;
        Problem.N = N;
        Problem.D = 22;
        Problem.upper = [2.5,2.0,0.2,0.2,0.4,0.2,0.2,0.2,0.2,0.4,...
            2,2,0.5,0.5,1.5,0.5,0.5,0.5,0.5,1.5,...
            5,10]; 
        Problem.lower = [0.1,0.1,0.01,0.01,0.1,0.01,0.01,0.01,0.01,0.05,...
            0.6,0.35,0.1,0.1,0.4,0.1,0.1,0.1,0.1,0.4,...
            0.1,0.5];
        Problem.MaxFE = FE;
        Problem.encoding = 'real';
        Problem.Optimum  = [2200,2200];
    end
end