function Solution = Fitness(x,fun)   
    if  strcmp(fun,'Case') 
        Solution = Case(x);
    end
end

function Solution = Case(X)
    PopObj(:,1) = Fitness1(X)'; % Pure Shear
    PopObj(:,2) = Fitness2(X)'; % Tension Shear
    
    PopCon      = (Fitness3(X) - 12.6)'; % Uniaxial Tension
    Solution.objs = PopObj;
    Solution.cons = PopCon;
    Solution.decs = X;
end

function Obj = Fitness1(x)
    % Pure Shear
    [m,n] = size(x);
    path = 'X:\XXX\DP800_Steel\';
    pathls = 'F:\LSDYNA\program'; % Path of LSDYNA
    load X:\XXX\DP800_Steel\LoadDisplacementCurves\PureShear.csv;
    [len,~] = size(PureShear); 
    for i = 1:m
        input1 = ceil(10000*x(i,1:10))/10000;
        input2 = ceil(10000*x(i,11:20))/10000;
        input3 = ceil(100000*x(i,21:22))/100000;

        for j = 1:10
            inputstr1{j} = compose('%8.4f',input1(j));
        end

        for j = 1:10
            inputstr2{j} = compose('%8.4f',input2(j));
        end

        for j = 1:2
            inputstr3{j} = compose('%9.5f',input3(j));
        end

        [fid,errmsg]=fopen([path,' ECRIT.k'],'w');
        if fid<0
            disp(errmsg);
        else
            k = 0;
            fprintf(fid,'*DEFINE_CURVE\n')
            fprintf(fid,'$HMNAME CURVES         3ECRIT\n')                                                                   
            fprintf(fid,'$HWCOLOR CURVES         3      3\n')
            fprintf(fid,'$HMCURVE     1    1 ECRIT                                                                           \n')
            fprintf(fid,'         3                 1.0       1.0   \n')
            fprintf(fid,['             0.01596           ',inputstr1{1}{1},'\n'])
            fprintf(fid,['             0.08146           ',inputstr1{2}{1},'\n'])
            fprintf(fid,['              0.3333           ',inputstr1{3}{1},'\n'])
            fprintf(fid,['             0.43945           ',inputstr1{4}{1},'\n'])
            fprintf(fid,['               0.527           ',inputstr1{5}{1},'\n'])
            fprintf(fid,['             0.56132           ',inputstr1{6}{1},'\n'])
            fprintf(fid,['             0.57301           ',inputstr1{7}{1},'\n'])
            fprintf(fid,['               0.577           ',inputstr1{8}{1},'\n'])
            fprintf(fid,['             0.58513           ',inputstr1{9}{1},'\n'])
            fprintf(fid,['              0.5958           ',inputstr1{10}{1},'\n'])
            fprintf(fid,'*END')
        end

        [fid,errmsg]=fopen([path,'LCSDG.k'],'w');
        if fid<0
            disp(errmsg);
        else
            k = 0;
            fprintf(fid,'*DEFINE_CURVE\n')
            fprintf(fid,'$HMNAME CURVES         6LCSDG                                                                   \n')
            fprintf(fid,'$HWCOLOR CURVES         6      30\n')                                                                   
            fprintf(fid,'$HMCURVE     1    1 LCSDG                                                                           \n')
            fprintf(fid,'         6                 1.0       1.0                              \n')
            fprintf(fid,['             0.01596           ',inputstr2{1}{1},'\n'])
            fprintf(fid,['             0.08146           ',inputstr2{2}{1},'\n'])
            fprintf(fid,['              0.3333           ',inputstr2{3}{1},'\n'])
            fprintf(fid,['             0.43945           ',inputstr2{4}{1},'\n'])
            fprintf(fid,['               0.527           ',inputstr2{5}{1},'\n'])
            fprintf(fid,['             0.56132           ',inputstr2{6}{1},'\n'])
            fprintf(fid,['             0.57301           ',inputstr2{7}{1},'\n'])
            fprintf(fid,['               0.577           ',inputstr2{8}{1},'\n'])
            fprintf(fid,['             0.58513           ',inputstr2{9}{1},'\n'])
            fprintf(fid,['              0.5958           ',inputstr2{10}{1},'\n'])
            fprintf(fid,'*END')
        end

        [fid,errmsg]=fopen([path,'FADEXP_DMGEXP.k'],'w');
        if fid<0
            disp(errmsg);
        else
            k = 0;
            fprintf(fid,'*PARAMETER\n')
            fprintf(fid,['R   FADEXP ',inputstr3{1}{1},'\n'])
            fprintf(fid,'*PARAMETER\n')                                                                   
            fprintf(fid,['R   DMGEXP ',inputstr3{2}{1},'\n'])
            fprintf(fid,'*END')
        end

        %% Run LS DYNA
        setenv('OMP_NUM_THREADS', '12');

        fid=fopen([path,'Calculation.bat'],'w');
        fprintf(fid,'%s\n',['cd ',path,'Models\PureShear']);
        fprintf(fid,'%s\n',['path=',pathls]);
        fprintf(fid,'%s\n','ls-dyna_smp_s_R11_0_winx64_ifort131.exe i=PureShear.k');
        fclose(fid); 
        system([path,'Calculation.bat'])

        % Write MV_OPT_OUTPUT.cfile
        fid=fopen([path,'MV_OPT_OUTPUT.cfile'],'w');
        fprintf(fid,'%s\n',['ascii secforc open "',path,'Models\PureShear\secforc"']);
        fprintf(fid,'%s\n','ascii secforc plot 4 Sec-1');
        fprintf(fid,'%s\n',['xyplot 1 savefile curve_file "',path,'Models\PureShear\Force.txt" 1 all 0 p0 p999999']);

        fprintf(fid,'%s\n',['ascii nodout open "',path,'Models\PureShear\nodout"']);
        fprintf(fid,'%s\n','ascii nodout plot 4 102170');
        fprintf(fid,'%s\n',['xyplot 1 savefile curve_file "',path,'Models\PureShear\Displacement.txt" 1 all 0 p0 p999999']);
        fprintf(fid,'%s\n','exit');
        fclose(fid);     

        % Run LS prepost  
        fid=fopen([path,'LS_postprocess.bat'],'w');
        fprintf(fid,'%s\n',['cd ',path]);
        fprintf(fid,'%s\n',['path=',pathls]);
        fprintf(fid,'%s\n','lsprepost.exe c=MV_OPT_OUTPUT.cfile');
        fclose(fid); 
        system([path,'LS_postprocess.bat'])

        %%% Extract data 
        fiddis=fopen([path,'Models\PureShear\Displacement.txt']);
        dis=textscan(fiddis,'%f%f','headerLines',8); 
        fclose(fiddis);
        fidfoc=fopen([path,'Models\PureShear\Force.txt']);
        foc=textscan(fidfoc,'%f%f','headerLines',8); 
        fclose(fidfoc);
        for k = 1:len
            [~,idx_min] = min(abs(dis{2}-PureShear(k,1)));
            D(k) = abs(foc{2}(idx_min) - PureShear(k,2));
        end
        Obj(i) = mean(abs(D));
    end
end

function Obj = Fitness2(x)
    % Tension Shear
    [m,n] = size(x);
    path   = 'X:\XXX\DP800_Steel\';
    pathls = 'F:\LSDYNA\program'; % Path of LSDYNA
    load X:\XXX\DP800_Steel\LoadDisplacementCurves\TensionShear.csv;
    [len,~] = size(TensionShear); 
    for i = 1:m
        input1 = ceil(10000*x(i,1:10))/10000;
        input2 = ceil(10000*x(i,11:20))/10000;
        input3 = ceil(100000*x(i,21:22))/100000;

        for j = 1:10
            inputstr1{j} = compose('%8.4f',input1(j));
        end

        for j = 1:10
            inputstr2{j} = compose('%8.4f',input2(j));
        end

        for j = 1:2
            inputstr3{j} = compose('%9.5f',input3(j));
        end

        [fid,errmsg]=fopen([path,'ECRIT.k'],'w');
        if fid<0
            disp(errmsg);
        else
            k = 0;
            fprintf(fid,'*DEFINE_CURVE\n')
            fprintf(fid,'$HMNAME CURVES         3ECRIT\n')                                                                   
            fprintf(fid,'$HWCOLOR CURVES         3      3\n')
            fprintf(fid,'$HMCURVE     1    1 ECRIT                                                                           \n')
            fprintf(fid,'         3                 1.0       1.0   \n')
            fprintf(fid,['             0.01596           ',inputstr1{1}{1},'\n'])
            fprintf(fid,['             0.08146           ',inputstr1{2}{1},'\n'])
            fprintf(fid,['              0.3333           ',inputstr1{3}{1},'\n'])
            fprintf(fid,['             0.43945           ',inputstr1{4}{1},'\n'])
            fprintf(fid,['               0.527           ',inputstr1{5}{1},'\n'])
            fprintf(fid,['             0.56132           ',inputstr1{6}{1},'\n'])
            fprintf(fid,['             0.57301           ',inputstr1{7}{1},'\n'])
            fprintf(fid,['               0.577           ',inputstr1{8}{1},'\n'])
            fprintf(fid,['             0.58513           ',inputstr1{9}{1},'\n'])
            fprintf(fid,['              0.5958           ',inputstr1{10}{1},'\n'])
            fprintf(fid,'*END')
        end

        [fid,errmsg]=fopen([path,'LCSDG.k'],'w');
        if fid<0
            disp(errmsg);
        else
            k = 0;
            fprintf(fid,'*DEFINE_CURVE\n')
            fprintf(fid,'$HMNAME CURVES         6LCSDG                                                                   \n')
            fprintf(fid,'$HWCOLOR CURVES         6      30\n')                                                                   
            fprintf(fid,'$HMCURVE     1    1 LCSDG                                                                           \n')
            fprintf(fid,'         6                 1.0       1.0                              \n')
            fprintf(fid,['             0.01596           ',inputstr2{1}{1},'\n'])
            fprintf(fid,['             0.08146           ',inputstr2{2}{1},'\n'])
            fprintf(fid,['              0.3333           ',inputstr2{3}{1},'\n'])
            fprintf(fid,['             0.43945           ',inputstr2{4}{1},'\n'])
            fprintf(fid,['               0.527           ',inputstr2{5}{1},'\n'])
            fprintf(fid,['             0.56132           ',inputstr2{6}{1},'\n'])
            fprintf(fid,['             0.57301           ',inputstr2{7}{1},'\n'])
            fprintf(fid,['               0.577           ',inputstr2{8}{1},'\n'])
            fprintf(fid,['             0.58513           ',inputstr2{9}{1},'\n'])
            fprintf(fid,['              0.5958           ',inputstr2{10}{1},'\n'])
            fprintf(fid,'*END')
        end

        [fid,errmsg]=fopen([path,'FADEXP_DMGEXP.k'],'w');
        if fid<0
            disp(errmsg);
            disp('不能打开文件');
        else
            k = 0;
            fprintf(fid,'*PARAMETER\n')
            fprintf(fid,['R   FADEXP ',inputstr3{1}{1},'\n'])
            fprintf(fid,'*PARAMETER\n')                                                                   
            fprintf(fid,['R   DMGEXP ',inputstr3{2}{1},'\n'])
            fprintf(fid,'*END')
        end

        %% Run LS DYNA
        setenv('OMP_NUM_THREADS', '12');
    
        fid=fopen([path,'Calculation.bat'],'w');
        fprintf(fid,'%s\n',['cd ',path,'Models\TensionShear']);
        fprintf(fid,'%s\n',['path=',pathls]);
        fprintf(fid,'%s\n','ls-dyna_smp_s_R11_0_winx64_ifort131.exe i=TensionShear.k');
        fclose(fid); 
        system([path,'Calculation.bat'])

        % Write MV_OPT_OUTPUT.cfile
        fid=fopen([path,'MV_OPT_OUTPUT.cfile'],'w');
        fprintf(fid,'%s\n',['ascii secforc open "',path,'Models\TensionShear\secforc"']);
        fprintf(fid,'%s\n','ascii secforc plot 4 Sec-1');
        fprintf(fid,'%s\n',['xyplot 1 savefile curve_file "',path,'Models\TensionShear\Force.txt" 1 all 0 p0 p999999']);

        fprintf(fid,'%s\n',['ascii nodout open "',path,'Models\TensionShear\nodout"']);
        fprintf(fid,'%s\n','ascii nodout plot 4 104184');
        fprintf(fid,'%s\n',['xyplot 1 savefile curve_file "',path,'Models\TensionShear\Displacement.txt" 1 all 0 p0 p999999']);
        fprintf(fid,'%s\n','exit');
        fclose(fid);     

        % Run LS prepost  
        fid=fopen([path,'LS_postprocess.bat'],'w');
        fprintf(fid,'%s\n',['cd ',path]);
        fprintf(fid,'%s\n',['path=',pathls]);
        fprintf(fid,'%s\n','lsprepost.exe c=MV_OPT_OUTPUT.cfile');
        fclose(fid); 
        system([path,'LS_postprocess.bat'])

        %%% Extract data 
        fiddis=fopen([path,'Models\TensionShear\Displacement.txt']);
        dis=textscan(fiddis,'%f%f','headerLines',8); 
        fclose(fiddis);
        fidfoc=fopen([path,'Models\TensionShear\Force.txt']);
        foc=textscan(fidfoc,'%f%f','headerLines',8); 
        fclose(fidfoc);
        for k = 1:len
            [~,idx_min] = min(abs(dis{2}-TensionShear(k,1)));
            D(k) = abs(foc{2}(idx_min) - TensionShear(k,2));
        end
        Obj(i) = sqrt(mean(abs(D)));
    end
end

function Obj = Fitness3(x)
    % Uniaxial Tension
    [m,n] = size(x);
    path   = 'X:\XXX\DP800_Steel\';
    pathls = 'F:\LSDYNA\program'; % Path of LSDYNA
    load X:\XXX\DP800_Steel\LoadDisplacementCurves\UniaxialTension.csv;
    [len,~] = size(UniaxialTension); 
    for i = 1:m
        input1 = ceil(10000*x(i,1:10))/10000;
        input2 = ceil(10000*x(i,11:20))/10000;
        input3 = ceil(100000*x(i,21:22))/100000;

        for j = 1:10
            inputstr1{j} = compose('%8.4f',input1(j));
        end

        for j = 1:10
            inputstr2{j} = compose('%8.4f',input2(j));
        end

        for j = 1:2
            inputstr3{j} = compose('%9.5f',input3(j));
        end

        [fid,errmsg]=fopen([path,'ECRIT.k'],'w');
        if fid<0
            disp(errmsg);
        else
            k = 0;
            fprintf(fid,'*DEFINE_CURVE\n')
            fprintf(fid,'$HMNAME CURVES         3ECRIT\n')                                                                   
            fprintf(fid,'$HWCOLOR CURVES         3      3\n')
            fprintf(fid,'$HMCURVE     1    1 ECRIT                                                                           \n')
            fprintf(fid,'         3                 1.0       1.0   \n')
            fprintf(fid,['             0.01596           ',inputstr1{1}{1},'\n'])
            fprintf(fid,['             0.08146           ',inputstr1{2}{1},'\n'])
            fprintf(fid,['              0.3333           ',inputstr1{3}{1},'\n'])
            fprintf(fid,['             0.43945           ',inputstr1{4}{1},'\n'])
            fprintf(fid,['               0.527           ',inputstr1{5}{1},'\n'])
            fprintf(fid,['             0.56132           ',inputstr1{6}{1},'\n'])
            fprintf(fid,['             0.57301           ',inputstr1{7}{1},'\n'])
            fprintf(fid,['               0.577           ',inputstr1{8}{1},'\n'])
            fprintf(fid,['             0.58513           ',inputstr1{9}{1},'\n'])
            fprintf(fid,['              0.5958           ',inputstr1{10}{1},'\n'])
            fprintf(fid,'*END')
        end

        [fid,errmsg]=fopen([path,'LCSDG.k'],'w');
        if fid<0
            disp(errmsg);
        else
            k = 0;
            fprintf(fid,'*DEFINE_CURVE\n')
            fprintf(fid,'$HMNAME CURVES         6LCSDG                                                                   \n')
            fprintf(fid,'$HWCOLOR CURVES         6      30\n')                                                                   
            fprintf(fid,'$HMCURVE     1    1 LCSDG                                                                           \n')
            fprintf(fid,'         6                 1.0       1.0                              \n')
            fprintf(fid,['             0.01596           ',inputstr2{1}{1},'\n'])
            fprintf(fid,['             0.08146           ',inputstr2{2}{1},'\n'])
            fprintf(fid,['              0.3333           ',inputstr2{3}{1},'\n'])
            fprintf(fid,['             0.43945           ',inputstr2{4}{1},'\n'])
            fprintf(fid,['               0.527           ',inputstr2{5}{1},'\n'])
            fprintf(fid,['             0.56132           ',inputstr2{6}{1},'\n'])
            fprintf(fid,['             0.57301           ',inputstr2{7}{1},'\n'])
            fprintf(fid,['               0.577           ',inputstr2{8}{1},'\n'])
            fprintf(fid,['             0.58513           ',inputstr2{9}{1},'\n'])
            fprintf(fid,['              0.5958           ',inputstr2{10}{1},'\n'])
            fprintf(fid,'*END')
        end

        [fid,errmsg]=fopen([path,'FADEXP_DMGEXP.k'],'w');
        if fid<0
            disp(errmsg);
        else
            k = 0;
            fprintf(fid,'*PARAMETER\n')
            fprintf(fid,['R   FADEXP ',inputstr3{1}{1},'\n'])
            fprintf(fid,'*PARAMETER\n')                                                                   
            fprintf(fid,['R   DMGEXP ',inputstr3{2}{1},'\n'])
            fprintf(fid,'*END')
        end

        %% Run LS DYNA
        setenv('OMP_NUM_THREADS', '12');

        fid=fopen([path,'Calculation.bat'],'w');
        fprintf(fid,'%s\n',['cd ',path,'Models\UniaxialTension']);
        fprintf(fid,'%s\n',['path=',pathls]);
        fprintf(fid,'%s\n','ls-dyna_smp_s_R11_0_winx64_ifort131.exe i=UniaxialTension.k');
        fclose(fid); 
        system([path,'Calculation.bat'])

        % Write MV_OPT_OUTPUT.cfile
        fid=fopen([path,'MV_OPT_OUTPUT.cfile'],'w');
        fprintf(fid,'%s\n',['ascii secforc open "',path,'Models\UniaxialTension\secforc"']);
        fprintf(fid,'%s\n','ascii secforc plot 4 Sec-1');
        fprintf(fid,'%s\n',['xyplot 1 savefile curve_file "',path,'Models\UniaxialTension\Force.txt" 1 all 0 p0 p999999']);

        fprintf(fid,'%s\n',['ascii nodout open "',path,'Models\UniaxialTension\nodout"']);
        fprintf(fid,'%s\n','ascii nodout plot 4 98816');
        fprintf(fid,'%s\n',['xyplot 1 savefile curve_file "',path,'Models\UniaxialTension\Displacement.txt" 1 all 0 p0 p999999']);
        fprintf(fid,'%s\n','exit');
        fclose(fid);     

        % Run LS prepost  
        fid=fopen([path,'LS_postprocess.bat'],'w');
        fprintf(fid,'%s\n',['cd ',path]);
        fprintf(fid,'%s\n',['path=',pathls]);
        fprintf(fid,'%s\n','lsprepost.exe c=MV_OPT_OUTPUT.cfile');
        fclose(fid); 
        system([path,'LS_postprocess.bat'])

        %%% Extract data 
        fiddis=fopen([path,'Models\UniaxialTension\Displacement.txt']);
        dis=textscan(fiddis,'%f%f','headerLines',8); 
        fclose(fiddis);
        fidfoc=fopen([path,'Models\UniaxialTension\Force.txt']);
        foc=textscan(fidfoc,'%f%f','headerLines',8); 
        fclose(fidfoc);
        for k = 1:len
            [~,idx_min] = min(abs(dis{2}-UniaxialTension(k,1)));
            D(k) = abs(foc{2}(idx_min) - UniaxialTension(k,2));
        end
        Obj(i) = sqrt(mean(abs(D)));
    end
end
